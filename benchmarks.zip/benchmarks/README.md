# UniHelp benchmark harness

Measurement-only HTTP client for a **running** UniHelp server. It does not
start the app, does not import planner/executor/agents, and does not change
production behavior.

## Prerequisites

1. The server must already be running:

   ```bash
   python main.py
   ```

   Default bind is `http://127.0.0.1:8002`.

2. This harness talks to **`POST /api/ask`** only:

   ```json
   {"message": "<user_input>", "authentication_key": "<key>"}
   ```

3. This is **not** an in-process benchmark. If nothing is listening on the
   base URL, rows are recorded as `status=request_failed` and the rest of
   the run continues.

## Files

| Path | Role |
| --- | --- |
| `queries.csv` | Fixed 18-query set. Do not regenerate or shuffle between runs. |
| `run_benchmark.py` | Drives `/api/ask`, writes `{label}.csv` and `{label}.md`. |
| `compare.py` | Side-by-side before/after report with `% change`. |

## Run a labeled measurement

```bash
python benchmarks/run_benchmark.py --label current --repeats 3
```

Later, against the same query file:

```bash
python benchmarks/run_benchmark.py --label baseline --repeats 3
python benchmarks/run_benchmark.py --label optimized --repeats 3
```

Optional flags:

- `--base-url` (default `http://127.0.0.1:8002`)
- `--timeout` (default 180 seconds per request)
- `--input-price-per-1k X`
- `--output-price-per-1k Y`
- `--cached-price-per-1k Z`

If no pricing flags are passed, `estimated_cost` is `0.0` and the script
prints a warning. It does not invent a price.

A typical run is `18 queries × 3 repeats = 54` CSV rows. Fewer rows appear
only when the process itself is interrupted; HTTP-level failures still
write a row (`status=request_failed`).

## Compare two runs

```bash
python benchmarks/compare.py \
    benchmarks/baseline.csv \
    benchmarks/optimized.csv \
    -o benchmarks/comparison.md
```

`% change` is `(before - after) / before * 100`. The report does not label
a change as an improvement. If a `query_id` exists in only one CSV, compare
warns, lists the unmatched IDs, excludes those rows from paired tables, and
still prints each file's own aggregate.

## Known limitations

1. The server must already be running with `python main.py`.
2. The benchmark communicates through `/api/ask`.
3. This is not an in-process benchmark.
4. `metrics.py` does not currently expose DB call count or DB-only latency
   (`db.py` and the `*_functions.py` modules do not report to `metrics`).
5. `approx_non_llm_latency_ms` therefore combines DB time with
   Python/tool/application overhead. It is useful for spotting whether
   non-LLM time is large, not as a true `db_calls` / `db_latency_ms`.
6. Application-level cache hits (bus schedule cache, authentication cache,
   etc.) are only reported if existing metrics expose them. They currently
   do not.
7. `cached_tokens` is LLM/provider prompt-cache usage from
   `request.tokens.cached`. A non-zero value must **not** be interpreted as
   an application cache hit.
8. Planner task `id`, `request`, `condition`, `depends_on`, and condition
   `type` are not serialized on `request.tasks` (`metrics.task_timer` stores
   `{feature, latency_ms}` only). Queries labeled `multi_dependent` cannot
   be confirmed from the public metrics record without changing production
   code, which this harness does not do.
9. `fast_path` / `synthesis_llm_used` are not named metrics fields.
   Zero `llm_calls` is reported as observed, without naming the mechanism.

Do not add DB instrumentation in this harness. That would mean touching
every function module's connection/query path.
